.class public Lin/startv/hotstar/ScreenshotEnabler$LifecycleCallback;
.super Ljava/lang/Object;
.source "ScreenshotEnabler.java"

.implements Landroid/app/Application$ActivityLifecycleCallbacks;

.method public constructor <init>()V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    return-void
.end method

# Called when any activity is created - clear FLAG_SECURE
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0
    invoke-static {p1}, Lin/startv/hotstar/ScreenshotEnabler;->clearSecureFlag(Landroid/app/Activity;)V
    return-void
.end method

# Called when any activity is resumed - clear FLAG_SECURE again
.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 0
    invoke-static {p1}, Lin/startv/hotstar/ScreenshotEnabler;->clearSecureFlag(Landroid/app/Activity;)V
    return-void
.end method

# Required interface methods (no-ops)
.method public onActivityStarted(Landroid/app/Activity;)V
    .locals 0
    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 0
    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 0
    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0
    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .locals 0
    return-void
.end method
