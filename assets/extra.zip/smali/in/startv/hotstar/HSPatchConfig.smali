.class public Lin/startv/hotstar/HSPatchConfig;
.super Ljava/lang/Object;
.source "HSPatchConfig.java"

# ================================================================
# HSPatchConfig - Central configuration for all HSPatch modules
# Holds the dynamic files directory path, initialized once at startup
# All other classes reference this instead of hardcoded paths
# ================================================================

# static fields
.field public static filesDir:Ljava/lang/String;
.field public static initialized:Z
.field public static autoResetFingerprint:Z
.field public static debugNotificationPersistent:Z
.field public static networkFilterEnabled:Z
.field public static blockingNotificationEnabled:Z
.field public static websocketKillEnabled:Z
.field public static appBarHideEnabled:Z
.field public static networkFilterMode:I    # 0 = Only Block (blacklist), 1 = Only Allow (whitelist)


# direct methods
.method public constructor <init>()V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    return-void
.end method


# ================================================================
# init(Context) - Called first in Application.onCreate()
# Sets filesDir to the app's INTERNAL files directory
# ================================================================
.method public static init(Landroid/content/Context;)V
    .locals 3

    sget-boolean v0, Lin/startv/hotstar/HSPatchConfig;->initialized:Z
    if-nez v0, :already_init

    :try_start
    # Prefer INTERNAL files dir (no scoped-storage issues)
    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;
    move-result-object v0

    if-eqz v0, :try_internal

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;
    move-result-object v0
    goto :dir_resolved

    :try_internal
    # Fallback to internal data dir
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;
    move-result-object v0
    iget-object v0, v0, Landroid/content/pm/ApplicationInfo;->dataDir:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2, "/files"
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0

    :dir_resolved
    sput-object v0, Lin/startv/hotstar/HSPatchConfig;->filesDir:Ljava/lang/String;

    # Ensure directory exists
    new-instance v1, Ljava/io/File;
    invoke-direct {v1, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    const/4 v0, 0x1
    sput-boolean v0, Lin/startv/hotstar/HSPatchConfig;->initialized:Z

    # Load autoResetFingerprint toggle from SharedPreferences
    const-string v0, "hspatch_settings"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    const-string v1, "auto_reset_fingerprint"
    const/4 v2, 0x1
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    move-result v1
    sput-boolean v1, Lin/startv/hotstar/HSPatchConfig;->autoResetFingerprint:Z

    # Load debug notification persistence toggle from SharedPreferences (default: ON)
    const-string v1, "debug_notification_persistent"
    const/4 v2, 0x1
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    move-result v1
    sput-boolean v1, Lin/startv/hotstar/HSPatchConfig;->debugNotificationPersistent:Z

    # Load network filter enabled toggle (default: true = ON)
    const-string v1, "network_filter_enabled"
    const/4 v2, 0x1
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    move-result v1
    sput-boolean v1, Lin/startv/hotstar/HSPatchConfig;->networkFilterEnabled:Z

    # Load network filter mode (default: 0 = Only Block)
    const-string v1, "network_filter_mode"
    const/4 v2, 0x0
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I
    move-result v1
    sput v1, Lin/startv/hotstar/HSPatchConfig;->networkFilterMode:I

    # Load blocking notification toggle (default: false = OFF)
    const-string v1, "blocking_notification"
    const/4 v2, 0x0
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    move-result v1
    sput-boolean v1, Lin/startv/hotstar/HSPatchConfig;->blockingNotificationEnabled:Z

    # Load websocket kill toggle (default: false = OFF)
    const-string v1, "websocket_kill"
    const/4 v2, 0x0
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    move-result v1
    sput-boolean v1, Lin/startv/hotstar/HSPatchConfig;->websocketKillEnabled:Z

    # Load app bar hide toggle (default: false = OFF)
    const-string v1, "appbar_hide"
    const/4 v2, 0x0
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z
    move-result v1
    sput-boolean v1, Lin/startv/hotstar/HSPatchConfig;->appBarHideEnabled:Z

    # Also sync to hspatch_config prefs (used by agent.js)
    const-string v0, "hspatch_config"
    const/4 v2, 0x0
    invoke-virtual {p0, v0, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    const-string v2, "blocking_notification"
    sget-boolean v1, Lin/startv/hotstar/HSPatchConfig;->blockingNotificationEnabled:Z
    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    const-string v2, "websocket_kill"
    sget-boolean v1, Lin/startv/hotstar/HSPatchConfig;->websocketKillEnabled:Z
    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    const-string v2, "appbar_hide"
    sget-boolean v1, Lin/startv/hotstar/HSPatchConfig;->appBarHideEnabled:Z
    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-string v0, "HSPatch"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Config initialized, filesDir="
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    sget-object v2, Lin/startv/hotstar/HSPatchConfig;->filesDir:Ljava/lang/String;
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :try_end
    .catchall {:try_start .. :try_end} :catch_init
    goto :after_init

    :catch_init
    move-exception v0
    # Fallback to internal data dir path
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;
    move-result-object v0
    iget-object v0, v0, Landroid/content/pm/ApplicationInfo;->dataDir:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2, "/files"
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0

    sput-object v0, Lin/startv/hotstar/HSPatchConfig;->filesDir:Ljava/lang/String;
    new-instance v1, Ljava/io/File;
    invoke-direct {v1, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    :after_init
    :already_init
    return-void
.end method


# ================================================================
# setBlockingNotificationEnabled(Context, boolean) - Persist toggle
# Also sync to hspatch_config prefs (used by agent.js)
# ================================================================
.method public static setBlockingNotificationEnabled(Landroid/content/Context;Z)V
    .locals 3

    sput-boolean p1, Lin/startv/hotstar/HSPatchConfig;->blockingNotificationEnabled:Z

    const-string v0, "hspatch_settings"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "blocking_notification"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    # Also sync to hspatch_config prefs (used by agent.js)
    const-string v0, "hspatch_config"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "blocking_notification"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method


# ================================================================
# getFilePath(String) - Build full path from filesDir + filename
# Returns: filesDir + "/" + filename
# ================================================================
.method public static getFilePath(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    sget-object v0, Lin/startv/hotstar/HSPatchConfig;->filesDir:Ljava/lang/String;
    if-nez v0, :has_dir

    # Not initialized yet, return filename as-is
    return-object p0

    :has_dir
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0, "/"
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method


# ================================================================
# getBlockingFileName() - Returns per-app blocking filename
# Format: blocking_<packageName>.txt, fallback: blocking_hotstar.txt
# ================================================================
.method public static getBlockingFileName()Ljava/lang/String;
    .locals 3

    :try_start_bn
    invoke-static {}, Landroid/app/ActivityThread;->currentApplication()Landroid/app/Application;
    move-result-object v0
    if-eqz v0, :fallback_bn

    invoke-virtual {v0}, Landroid/app/Application;->getPackageName()Ljava/lang/String;
    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "blocking_"
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2, ".txt"
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0

    :try_end_bn
    .catchall {:try_start_bn .. :try_end_bn} :catch_bn

    :catch_bn
    move-exception v0

    :fallback_bn
    const-string v0, "blocking_hotstar.txt"
    return-object v0
.end method


# ================================================================
# getBlockingFilePath() - Returns full path to first found blocking file
# Search order: blocking_<pkg>.txt > blocking_rules.txt > blocking_hotstar.txt
# Only checked in app-private filesDir (no shared/external storage)
# Returns null if no file found
# ================================================================
.method public static getBlockingFilePath()Ljava/lang/String;
    .locals 3

    # 1. Per-app file in filesDir
    invoke-static {}, Lin/startv/hotstar/HSPatchConfig;->getBlockingFileName()Ljava/lang/String;
    move-result-object v0

    invoke-static {v0}, Lin/startv/hotstar/HSPatchConfig;->getFilePath(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    new-instance v2, Ljava/io/File;
    invoke-direct {v2, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    invoke-virtual {v2}, Ljava/io/File;->exists()Z
    move-result v2
    if-nez v2, :return_path

    # 2. Generic blocking_rules.txt in filesDir
    const-string v0, "blocking_rules.txt"
    invoke-static {v0}, Lin/startv/hotstar/HSPatchConfig;->getFilePath(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    new-instance v2, Ljava/io/File;
    invoke-direct {v2, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    invoke-virtual {v2}, Ljava/io/File;->exists()Z
    move-result v2
    if-nez v2, :return_path

    # 3. Legacy blocking_hotstar.txt in filesDir
    const-string v0, "blocking_hotstar.txt"
    invoke-static {v0}, Lin/startv/hotstar/HSPatchConfig;->getFilePath(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    new-instance v2, Ljava/io/File;
    invoke-direct {v2, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    invoke-virtual {v2}, Ljava/io/File;->exists()Z
    move-result v2
    if-nez v2, :return_path

    # Nothing found
    const/4 v0, 0x0
    return-object v0

    :return_path
    return-object v1
.end method


# ================================================================
# setDebugNotificationPersistent(Context, boolean) - Persist toggle
# ================================================================
.method public static setDebugNotificationPersistent(Landroid/content/Context;Z)V
    .locals 3

    sput-boolean p1, Lin/startv/hotstar/HSPatchConfig;->debugNotificationPersistent:Z

    const-string v0, "hspatch_settings"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "debug_notification_persistent"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method


# ================================================================
# setAutoResetFingerprint(Context, boolean) - Persist toggle
# ================================================================
.method public static setAutoResetFingerprint(Landroid/content/Context;Z)V
    .locals 3

    sput-boolean p1, Lin/startv/hotstar/HSPatchConfig;->autoResetFingerprint:Z

    const-string v0, "hspatch_settings"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "auto_reset_fingerprint"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method


# ================================================================
# setNetworkFilterEnabled(Context, boolean) - Persist toggle
# ================================================================
.method public static setNetworkFilterEnabled(Landroid/content/Context;Z)V
    .locals 3

    sput-boolean p1, Lin/startv/hotstar/HSPatchConfig;->networkFilterEnabled:Z

    const-string v0, "hspatch_settings"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "network_filter_enabled"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    # Also sync to hspatch_config prefs (used by agent.js)
    const-string v0, "hspatch_config"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "blocking_enabled"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method


# ================================================================
# setNetworkFilterMode(Context, int) - Persist filter mode
# 0 = Only Block (blacklist), 1 = Only Allow (whitelist)
# ================================================================
.method public static setNetworkFilterMode(Landroid/content/Context;I)V
    .locals 3

    sput p1, Lin/startv/hotstar/HSPatchConfig;->networkFilterMode:I

    const-string v0, "hspatch_settings"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "network_filter_mode"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    # Also sync to hspatch_config prefs (used by agent.js)
    const-string v0, "hspatch_config"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "network_filter_mode"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method


# ================================================================
# getHostRulesFilePath() - Returns path to host_rules.txt
# ================================================================
.method public static getHostRulesFilePath()Ljava/lang/String;
    .locals 1

    const-string v0, "host_rules.txt"
    invoke-static {v0}, Lin/startv/hotstar/HSPatchConfig;->getFilePath(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method


# ================================================================
# setWebsocketKillEnabled(Context, boolean) - Persist toggle
# Also sync to hspatch_config prefs (used by agent.js)
# ================================================================
.method public static setWebsocketKillEnabled(Landroid/content/Context;Z)V
    .locals 3

    sput-boolean p1, Lin/startv/hotstar/HSPatchConfig;->websocketKillEnabled:Z

    const-string v0, "hspatch_settings"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "websocket_kill"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    # Also sync to hspatch_config prefs (used by agent.js)
    const-string v0, "hspatch_config"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "websocket_kill"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

# ================================================================
# setAppBarHideEnabled(Context, boolean) - Persist toggle
# Also sync to hspatch_config prefs (used by agent.js)
# ================================================================
.method public static setAppBarHideEnabled(Landroid/content/Context;Z)V
    .locals 3

    sput-boolean p1, Lin/startv/hotstar/HSPatchConfig;->appBarHideEnabled:Z

    const-string v0, "hspatch_settings"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "appbar_hide"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    # Also sync to hspatch_config prefs (used by agent.js)
    const-string v0, "hspatch_config"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v1
    const-string v2, "appbar_hide"
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method
